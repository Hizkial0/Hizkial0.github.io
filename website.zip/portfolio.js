const toggle=document.querySelector('.menu-toggle');
const nav=document.querySelector('.nav');
toggle?.addEventListener('click',()=>{const open=toggle.getAttribute('aria-expanded')!=='true';toggle.setAttribute('aria-expanded',String(open));nav.classList.toggle('is-open',open);});
nav?.addEventListener('click',e=>{if(e.target.closest('a')){toggle?.setAttribute('aria-expanded','false');nav.classList.remove('is-open');}});
const dialog=document.querySelector('.site-dialog');
let returnFocus;
document.addEventListener('click',e=>{const target=e.target.closest('[data-image-open]');if(!target||!dialog)return;returnFocus=target;dialog.querySelector('img').src=target.dataset.imageOpen;dialog.querySelector('img').alt=target.dataset.imageAlt||'Project evidence';dialog.querySelector('a').href=target.dataset.imageOpen;dialog.showModal();});
dialog?.querySelector('.dialog-close')?.addEventListener('click',()=>dialog.close());
dialog?.addEventListener('click',e=>{if(e.target===dialog)dialog.close();});
dialog?.addEventListener('close',()=>returnFocus?.focus());

const filters=[...document.querySelectorAll('[data-filter]')];
const projects=[...document.querySelectorAll('[data-category]')];
filters.forEach(button=>button.addEventListener('click',()=>{
 const selected=button.dataset.filter;
 filters.forEach(item=>item.setAttribute('aria-pressed',String(item===button)));
 let visible=0;
 projects.forEach(project=>{const show=selected==='all'||project.dataset.category.split(' ').includes(selected);project.hidden=!show;if(show)visible++;});
 const empty=document.querySelector('.empty-filter');if(empty)empty.hidden=visible>0;
}));
